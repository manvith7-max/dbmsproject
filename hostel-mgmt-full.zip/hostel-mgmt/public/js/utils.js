// ─── AUTH HELPERS ───
function getToken() { return localStorage.getItem('hms_token'); }
function getUsername() { return localStorage.getItem('hms_user'); }
function requireAuth() {
    if (!getToken()) { window.location.href = '/login.html'; return false; }
    return true;
}
function logout() {
    localStorage.removeItem('hms_token');
    localStorage.removeItem('hms_user');
    window.location.href = '/login.html';
}

// ─── API HELPER ───
async function api(path, options = {}) {
    const token = getToken();
    const res = await fetch(path, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...(options.headers || {})
        },
        body: options.body ? JSON.stringify(options.body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
    return data;
}

// ─── TOAST ───
function toast(msg, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span>${type === 'success' ? '✓' : '✕'}</span> ${msg}`;
    container.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity 0.3s'; setTimeout(() => el.remove(), 300); }, 3000);
}

// ─── MODAL HELPERS ───
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
});

// ─── FORMAT HELPERS ───
function formatDate(d) {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function formatCurrency(n) {
    if (!n) return '—';
    return '₹' + Number(n).toLocaleString('en-IN');
}
function statusBadge(status) {
    const map = {
        'Available': 'badge-green',
        'Occupied': 'badge-yellow',
        'Paid': 'badge-green',
        'Pending': 'badge-yellow',
        'Failed': 'badge-red',
        'Male': 'badge-blue',
        'Female': 'badge-purple'
    };
    return `<span class="badge ${map[status] || 'badge-blue'}">${status}</span>`;
}

// ─── TABLE SEARCH ───
function initTableSearch(inputId, tableBodyId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.addEventListener('input', () => {
        const q = input.value.toLowerCase();
        document.querySelectorAll(`#${tableBodyId} tr`).forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
}

// ─── SIDEBAR ACTIVE ───
function setActiveNav() {
    const page = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) item.classList.add('active');
    });
}

// ─── USER CHIP ───
function initUserChip() {
    const el = document.getElementById('username-display');
    const av = document.getElementById('user-avatar');
    const name = getUsername() || 'Admin';
    if (el) el.textContent = name;
    if (av) av.textContent = name.charAt(0).toUpperCase();
}
