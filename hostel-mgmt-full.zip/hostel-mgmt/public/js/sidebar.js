// Sidebar HTML injected by each page
function renderSidebar(activePage) {
  const nav = [
    { icon: '⊞', label: 'Dashboard', page: 'index.html', href: '/' },
    { icon: '👤', label: 'Students', page: 'students.html', href: '/students.html' },
    { icon: '🏢', label: 'Blocks', page: 'blocks.html', href: '/blocks.html' },
    { icon: '🛏', label: 'Rooms', page: 'rooms.html', href: '/rooms.html' },
    { icon: '💳', label: 'Payments', page: 'payments.html', href: '/payments.html' },
    { icon: '🔧', label: 'Facilities', page: 'facilities.html', href: '/facilities.html' },
  ];
  return `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-logo">
        <div class="logo-icon">🏨</div>
        <h1>Hostel Management</h1>
        <span>NMAMIT · Admin</span>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-label">Menu</div>
        ${nav.map(item => `
          <a class="nav-item${item.page === activePage ? ' active' : ''}" href="${item.href}" data-page="${item.page}">
            <span class="nav-icon">${item.icon}</span>
            ${item.label}
          </a>
        `).join('')}
      </nav>
      <div class="sidebar-footer">
        <div class="user-chip">
          <div class="user-avatar" id="user-avatar">A</div>
          <span class="user-name" id="username-display">Admin</span>
          <button class="logout-btn" onclick="logout()" title="Logout">⏻</button>
        </div>
      </div>
    </aside>
  `;
}
