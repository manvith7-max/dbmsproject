const express = require('express');
const router = express.Router();
const { getAllPayments, addPayment, updatePaymentStatus } = require('../controllers/paymentController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllPayments);
router.post('/', auth, addPayment);
router.patch('/:id/status', auth, updatePaymentStatus);

module.exports = router;
