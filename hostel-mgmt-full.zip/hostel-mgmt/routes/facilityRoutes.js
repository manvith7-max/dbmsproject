const express = require('express');
const router = express.Router();
const { getAllFacilities, addFacility } = require('../controllers/facilityController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllFacilities);
router.post('/', auth, addFacility);

module.exports = router;
