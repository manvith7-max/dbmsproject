const express = require('express');
const router = express.Router();
const { getAllBlocks, addBlock, deleteBlock } = require('../controllers/blockController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllBlocks);
router.post('/', auth, addBlock);
router.delete('/:id', auth, deleteBlock);

module.exports = router;
