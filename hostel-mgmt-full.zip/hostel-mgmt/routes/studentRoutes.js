const express = require('express');
const router = express.Router();
const { getAllStudents, addStudent, deleteStudent, getStats } = require('../controllers/studentController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllStudents);
router.get('/stats', auth, getStats);
router.post('/', auth, addStudent);
router.delete('/:id', auth, deleteStudent);

module.exports = router;
