const express = require('express');
const router = express.Router();
const { getAllRooms, getEmptyRooms, getAllocatedRooms, addRoom, allocateRoom } = require('../controllers/roomController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllRooms);
router.get('/empty', auth, getEmptyRooms);
router.get('/allocated', auth, getAllocatedRooms);
router.post('/', auth, addRoom);
router.post('/allocate', auth, allocateRoom);

module.exports = router;
