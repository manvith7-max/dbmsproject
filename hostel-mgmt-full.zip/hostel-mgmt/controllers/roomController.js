const db = require('../config/db');

exports.getAllRooms = (req, res) => {
    const sql = `
        SELECT r.room_id, r.room_type, r.capacity, r.status,
               b.block_name, b.location,
               COUNT(a.student_id) AS occupants
        FROM Room r
        JOIN Block b ON r.block_id = b.block_id
        LEFT JOIN Allocation a ON r.room_id = a.room_id
        GROUP BY r.room_id, r.room_type, r.capacity, r.status, b.block_name, b.location
        ORDER BY b.block_name, r.room_id
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch rooms', error: err.message });
        res.json(results);
    });
};

exports.getEmptyRooms = (req, res) => {
    const sql = `
        SELECT r.room_id, r.room_type, r.capacity, r.status,
               b.block_name, b.location
        FROM Room r
        JOIN Block b ON r.block_id = b.block_id
        WHERE r.status = 'Available'
        ORDER BY b.block_name, r.room_id
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch empty rooms', error: err.message });
        res.json(results);
    });
};

exports.getAllocatedRooms = (req, res) => {
    const sql = `
        SELECT r.room_id, r.room_type, r.capacity, r.status,
               b.block_name, s.student_id, s.name AS student_name,
               a.allocation_date
        FROM Room r
        JOIN Block b ON r.block_id = b.block_id
        JOIN Allocation a ON r.room_id = a.room_id
        JOIN Student s ON a.student_id = s.student_id
        WHERE r.status = 'Occupied'
        ORDER BY b.block_name, r.room_id
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch allocated rooms', error: err.message });
        res.json(results);
    });
};

exports.addRoom = (req, res) => {
    const { block_id, room_type, capacity } = req.body;
    if (!block_id || !room_type || !capacity)
        return res.status(400).json({ message: 'block_id, room_type, and capacity required' });
    db.query(
        "INSERT INTO Room (block_id, room_type, capacity, status) VALUES (?, ?, ?, 'Available')",
        [block_id, room_type, capacity],
        (err, result) => {
            if (err) return res.status(500).json({ message: 'Failed to add room', error: err.message });
            res.status(201).json({ message: 'Room added', room_id: result.insertId });
        }
    );
};

exports.allocateRoom = (req, res) => {
    const { student_id, room_id } = req.body;
    if (!student_id || !room_id)
        return res.status(400).json({ message: 'student_id and room_id required' });

    const allocation_date = new Date().toISOString().split('T')[0];
    db.query('INSERT INTO Allocation (student_id, room_id, allocation_date) VALUES (?, ?, ?)',
        [student_id, room_id, allocation_date], (err) => {
            if (err) return res.status(500).json({ message: 'Allocation failed', error: err.message });
            db.query("UPDATE Room SET status = 'Occupied' WHERE room_id = ?", [room_id], (err2) => {
                if (err2) return res.status(500).json({ message: 'Status update failed', error: err2.message });
                res.status(201).json({ message: 'Room allocated successfully' });
            });
        }
    );
};
