const db = require('../config/db');

exports.getAllBlocks = (req, res) => {
    const sql = `
        SELECT b.block_id, b.block_name, b.location,
               COUNT(DISTINCT r.room_id) AS total_rooms,
               COUNT(DISTINCT CASE WHEN r.status = 'Available' THEN r.room_id END) AS available_rooms,
               GROUP_CONCAT(DISTINCT f.facility_name ORDER BY f.facility_name SEPARATOR ', ') AS facilities
        FROM Block b
        LEFT JOIN Room r ON b.block_id = r.block_id
        LEFT JOIN Block_Facility bf ON b.block_id = bf.block_id
        LEFT JOIN Facility f ON bf.facility_id = f.facility_id
        GROUP BY b.block_id, b.block_name, b.location
        ORDER BY b.block_name
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch blocks', error: err.message });
        res.json(results);
    });
};

exports.addBlock = (req, res) => {
    const { block_name, location } = req.body;
    if (!block_name || !location)
        return res.status(400).json({ message: 'block_name and location required' });
    db.query('INSERT INTO Block (block_name, location) VALUES (?, ?)', [block_name, location], (err, result) => {
        if (err) return res.status(500).json({ message: 'Failed to add block', error: err.message });
        res.status(201).json({ message: 'Block added', block_id: result.insertId });
    });
};

exports.deleteBlock = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM Block WHERE block_id = ?', [id], (err) => {
        if (err) return res.status(500).json({ message: 'Failed to delete block', error: err.message });
        res.json({ message: 'Block deleted' });
    });
};
