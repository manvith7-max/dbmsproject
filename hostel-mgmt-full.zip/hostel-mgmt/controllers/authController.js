const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

exports.register = (req, res) => {
    const { username, password } = req.body;
    if (!username || !password)
        return res.status(400).json({ message: 'Username and password required' });

    const hash = bcrypt.hashSync(password, 10);
    db.query('INSERT INTO User (username, password) VALUES (?, ?)', [username, hash], (err) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY')
                return res.status(409).json({ message: 'Username already exists' });
            return res.status(500).json({ message: 'Registration failed', error: err.message });
        }
        res.status(201).json({ message: 'User registered successfully' });
    });
};

exports.login = (req, res) => {
    const { username, password } = req.body;
    if (!username || !password)
        return res.status(400).json({ message: 'Username and password required' });

    db.query('SELECT * FROM User WHERE username = ?', [username], (err, results) => {
        if (err) return res.status(500).json({ message: 'Login failed', error: err.message });
        if (results.length === 0)
            return res.status(401).json({ message: 'Invalid credentials' });

        const user = results[0];
        if (!bcrypt.compareSync(password, user.password))
            return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { user_id: user.user_id, username: user.username },
            process.env.JWT_SECRET || 'supersecret',
            { expiresIn: '8h' }
        );
        res.json({ message: 'Login successful', token, username: user.username });
    });
};
