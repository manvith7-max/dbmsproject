const db = require('../config/db');

exports.getAllPayments = (req, res) => {
    const sql = `
        SELECT p.payment_id, p.amount, p.payment_date, p.payment_mode, p.status,
               s.student_id, s.name AS student_name, s.phone
        FROM Payment p
        JOIN Student s ON p.student_id = s.student_id
        ORDER BY p.payment_date DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch payments', error: err.message });
        res.json(results);
    });
};

exports.addPayment = (req, res) => {
    const { student_id, amount, payment_mode, status } = req.body;
    if (!student_id || !amount || !payment_mode)
        return res.status(400).json({ message: 'student_id, amount, and payment_mode required' });

    const payment_date = new Date().toISOString().split('T')[0];
    db.query(
        'INSERT INTO Payment (student_id, amount, payment_date, payment_mode, status) VALUES (?, ?, ?, ?, ?)',
        [student_id, amount, payment_date, payment_mode, status || 'Paid'],
        (err, result) => {
            if (err) return res.status(500).json({ message: 'Failed to add payment', error: err.message });
            res.status(201).json({ message: 'Payment recorded', payment_id: result.insertId });
        }
    );
};

exports.updatePaymentStatus = (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    db.query('UPDATE Payment SET status = ? WHERE payment_id = ?', [status, id], (err) => {
        if (err) return res.status(500).json({ message: 'Update failed', error: err.message });
        res.json({ message: 'Payment status updated' });
    });
};
