const db = require('../config/db');

exports.getAllStudents = (req, res) => {
    const sql = `
        SELECT s.student_id, s.name, s.dob, s.gender, s.phone, s.parent_number,
               r.room_id, b.block_name,
               p.status AS payment_status,
               m.mess_name
        FROM Student s
        LEFT JOIN Allocation a ON s.student_id = a.student_id
        LEFT JOIN Room r ON a.room_id = r.room_id
        LEFT JOIN Block b ON r.block_id = b.block_id
        LEFT JOIN Payment p ON s.student_id = p.student_id
        LEFT JOIN Student_Mess sm ON s.student_id = sm.student_id
        LEFT JOIN Mess m ON sm.mess_id = m.mess_id
        ORDER BY s.name
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch students', error: err.message });
        res.json(results);
    });
};

exports.addStudent = (req, res) => {
    const { student_id, name, dob, gender, phone, parent_number } = req.body;
    if (!name || !gender || !phone)
        return res.status(400).json({ message: 'name, gender, and phone required' });
    db.query(
        'INSERT INTO Student (student_id, name, dob, gender, phone, parent_number) VALUES (?, ?, ?, ?, ?, ?)',
        [student_id || null, name, dob || null, gender, phone, parent_number || null],
        (err, result) => {
            if (err) return res.status(500).json({ message: 'Failed to add student', error: err.message });
            res.status(201).json({ message: 'Student added', student_id: result.insertId });
        }
    );
};

exports.deleteStudent = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM Student WHERE student_id = ?', [id], (err) => {
        if (err) return res.status(500).json({ message: 'Failed to delete student', error: err.message });
        res.json({ message: 'Student deleted' });
    });
};

exports.getStats = (req, res) => {
    const queries = {
        total_students: 'SELECT COUNT(*) AS count FROM Student',
        total_rooms: 'SELECT COUNT(*) AS count FROM Room',
        available_rooms: "SELECT COUNT(*) AS count FROM Room WHERE status = 'Available'",
        pending_payments: "SELECT COUNT(*) AS count FROM Payment WHERE status = 'Pending'",
        total_blocks: 'SELECT COUNT(*) AS count FROM Block'
    };
    const stats = {};
    let pending = Object.keys(queries).length;
    let errored = false;

    for (const [key, sql] of Object.entries(queries)) {
        db.query(sql, (err, rows) => {
            if (errored) return;
            if (err) {
                errored = true;
                return res.status(500).json({ message: 'Stats query failed', error: err.message });
            }
            stats[key] = rows[0].count;
            if (--pending === 0) res.json(stats);
        });
    }
};
