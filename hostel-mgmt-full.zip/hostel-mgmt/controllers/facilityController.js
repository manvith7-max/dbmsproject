const db = require('../config/db');

exports.getAllFacilities = (req, res) => {
    const sql = `
        SELECT f.facility_id, f.facility_name, f.availability,
               GROUP_CONCAT(b.block_name ORDER BY b.block_name SEPARATOR ', ') AS blocks
        FROM Facility f
        LEFT JOIN Block_Facility bf ON f.facility_id = bf.facility_id
        LEFT JOIN Block b ON bf.block_id = b.block_id
        GROUP BY f.facility_id, f.facility_name, f.availability
        ORDER BY f.facility_name
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch facilities', error: err.message });
        res.json(results);
    });
};

exports.addFacility = (req, res) => {
    const { facility_name, availability } = req.body;
    if (!facility_name) return res.status(400).json({ message: 'facility_name required' });
    db.query(
        "INSERT INTO Facility (facility_name, availability) VALUES (?, ?)",
        [facility_name, availability || 'Available'],
        (err, result) => {
            if (err) return res.status(500).json({ message: 'Failed to add facility', error: err.message });
            res.status(201).json({ message: 'Facility added', facility_id: result.insertId });
        }
    );
};
